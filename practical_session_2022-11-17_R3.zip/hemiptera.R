getwd() # проверяем рабочую диреткорию (и при необходимости изменяем)

hemiptera=read.csv('hemiptera.csv', sep=';') # откроем файл hemiptera.csv, 
# sep=';' - разделитель
names(hemiptera)


install.packages("vegan") # установим пакет vegan
library(vegan) # включим пакет vegan


## Посчитаем альфа-разнообразие
## Сколько видов в кажом биотопе

hemiptera.pa=decostand(hemiptera[, -1], method='pa') #переводим наши данные в присутствие/отсутствие
res.alpha=apply(hemiptera.pa[, -1], 1, sum) # считаем суммы по строкам
# hemiptera.pa[, -1] наши данные без учета столбца 1 (с типами биотопов)
# 1 - расчет ведем по строкам (2 - по столбцам)
# sum - считаем сумму

barplot(res.alpha)

colors.alfa.div=c('dodgerblue2', 'darkolivegreen3', 'darkorange2', 'darkorchid1',  'goldenrod3')

barplot(res.alpha, ylim=c(0,20), col=colors.alfa.div, las=1, 
        ylab='Альфа-разнообразие', xlab='Типы биотопов',
        cex.lab=1.5, cex.axis=1.5,
        main='Разнообразие клопов в исследованных биотопах', cex.main=1.5)
legend('top', legend=hemiptera[, 1], pch=15, bty='n', col=colors.alfa.div, cex=1.25)
# bty='n' - не рисовать рамочку вокруг легенды

## Посчитаем индекс Шеннона
diversity(hemiptera[, -1], index='shannon')
sh.res=round(diversity(hemiptera[, -1], index='shannon'),1)

## Посчитаем выровненность по Пиелу
# индекс Шеннона поделить на логарифм от числа видов
sh.res/log(res.alpha)
pielou.res=round(sh.res/log(res.alpha),2)

# индекс Бергера-Паркера
# формула Обилие самого обильного вида / сумма обилий всех видов на площадке

berg1=max(hemiptera[1, -1])/sum(hemiptera[1, -1])
berg2=max(hemiptera[2, -1])/sum(hemiptera[2, -1])
berg3=max(hemiptera[3, -1])/sum(hemiptera[3, -1])
berg4=max(hemiptera[4, -1])/sum(hemiptera[4, -1])
berg5=max(hemiptera[5, -1])/sum(hemiptera[5, -1])

berg.res=c(berg1, berg2, berg3, berg4, berg5)

# обратный индекс 1/индекс, тогда чем он больше тем больше разнообразие и меньше степень доминирования одного вида
berg.res.rec=round(1/berg.res,1)

###Соберем результаты в одну таблицу и запишем в файл

cbind(hemiptera$habitat, res.alpha, sh.res, pielou.res, berg.res.rec)
# cbind - сцепить несколько векторов с результатами

divers.res=cbind(hemiptera$habitat, res.alpha, sh.res, berg.res.rec)
# запишем результат работы функции cbind() в переменную divers.res

write.csv(divers.res, 'results.csv')
# сохранить таблицу в CSV файл
# divers.res - название таблицы в R
# results.res - название файла

#####
#####
##### Оценим бета-разнообразие

#####Сходство по Жаккару
##### https://ru.wikipedia.org/wiki/%D0%9A%D0%BE%D1%8D%D1%84%D1%84%D0%B8%D1%86%D0%B8%D0%B5%D0%BD%D1%82_%D0%96%D0%B0%D0%BA%D0%BA%D0%B0%D1%80%D0%B0
vegdist(hemiptera[, -1], method="jaccard", binary=TRUE)
# функция для рассчета расстояний
# method="jaccard" - расстояник Жаккара
# binary=TRUE - делаем наши данные бинарными (присутствие отсутствие)

round(vegdist(hemiptera[, -1], method="jaccard", binary=TRUE), 1)
# округлим результаты до 1 знака после запятой

###### гамма-разнообразие
dim(hemiptera)[2]-1
# из числа столбцов в таблице hemiptera вычитаем 1 (столбец с типами местообитаний)

### кластерный анализ
?dist
?hclust
# вызываем справку по функциям dist и hclust

dist.euc=dist(hemiptera[, -1], method='euclidean')
# рассчитываем расстояние между объектами
# мера расстояния - Евклидово расстояние
hc=hclust(dist.euc, method='average')
# выполняем кластерный анализ по методу average (UPGMA)
plot(hc)
# строим дедрограмму


### метод k-средних (классификация)
kmeans(hemiptera[, -1], 3)
# функция для расчета. Указываем данные и на сколько групп мы хотим их разделить (3)

cl=kmeans(hemiptera[, -1], 3)
# записать результаты в переменную cl
# cl$cluster - номера кластеров

cbind(hemiptera$habitat,cl$cluster)
# соединим выделенные номера кластеров и типы сообществ

####### ординация
install.packages("factoextra")
install.packages("labeling")

library('factoextra')

## PCA
  # подробности о методе здесь https://f0nzie.github.io/machine_learning_compilation/detailed-study-of-principal-component-analysis.html

hem.pca.res=prcomp(hemiptera[, -1],  scale = TRUE)

eig.val <- get_eigenvalue(hem.pca.res)
eig.val
fviz_eig(hem.pca.res, addlabels = TRUE, ylim = c(0, 50))
# построим график с собственными числами, посмотрим что происходит с объясненной вариацией

var <- get_pca_var(hem.pca.res)
var
# запишем результаты ординации в переменную var

library("corrplot")
corrplot(var$contrib, is.corr=FALSE)  
# посмотреть вклад разных видов в компоненты

biplot(hem.pca.res)
# визуализация базовыми средствами


fviz_pca_ind(hem.pca.res,
             geom.ind = "point", # show points only (nbut not "text")
             col.ind = hemiptera$habitat, # color by groups
             palette = c('#1890F8', '#E07000', '#801088', '#402088','#E81008'),
             legend.title = "Habitats",
             pointsize=3) +
labs(title ="PCA ", x = "PC1 (46.5%)", y = "PC2 (24.3%)") +
theme(legend.text = element_text(size=12), legend.title=element_text(size=12, face='bold'))
