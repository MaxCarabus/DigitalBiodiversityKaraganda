# что, если выборок больше двух?

iris #  вызовем вложенные в R данные по ирисам
#https://ru.wikipedia.org/wiki/%D0%98%D1%80%D0%B8%D1%81%D1%8B_%D0%A4%D0%B8%D1%88%D0%B5%D1%80%D0%B0
# sepal - чашелистик
# petal - лепесток
# эти данные уже имеют свое имя, их не нужно записывать в отдельную переменную
class(iris) # узнать класс объекта iris
names(iris) # показать заголовки полей (столбцов) в таблице iris

#Визуализация

colors=c('darkslateblue', 'darkorchid1', 'darkmagenta') # заготовим вектор цветов для раскрашивания

boxplot(iris$Sepal.Length~iris$Species, range=0, col=colors, main='Sepal boxplot')
# боксплот, усф показывают мин и макс (range=0)

# Сравним три средних значения при помощи однофакторного дисперсионного анализа (ANOVA)
summary(aov(iris$Sepal.Length~as.factor(iris$Species)))
# as.factor(iris$Species) - указываем, что виды нужно рассматривать как фактор
# iris$Sepal.Length~as.factor(iris$Species) - данные для дисперс. анализа по форме
# измерения~фактор
# aov - функция для проведения ANOVA
# summary - вывести результаты работы ANOVA
# из результатов дисп. анализа, мы узнаем, есть ли значимые раздичия между группами
# на следующем этапе необходиом выяснить, в каких именно парах эти различия значимы

plot(TukeyHSD(aov(iris$Sepal.Length~as.factor(iris$Species))))
# aov(iris$Sepal.Length~as.factor(iris$Species)) - объект дисперсионного анализа
# TukeyHSD - функция, которая оценивает на значимость различия между всеми парами
# plot - для визуализации попарных сранений
# Обратите внимание, что plot - умная функция, она сама понимает, какой тип графика 
# строить для таких входных данных

# Построим боксплоты для всех 4х измеренных переменных
par(mfrow=c(2,2))
boxplot(iris$Sepal.Length~iris$Species, range=0, col=colors, main='Sepal.Length')
boxplot(iris$Sepal.Width~iris$Species, range=0, col=colors, main='Sepal.Width')
boxplot(iris$Petal.Length~iris$Species, range=0, col=colors, main='Petal.Length')
boxplot(iris$Petal.Width~iris$Species, range=0, col=colors, main='Petal.Width')


##### как раскрасить plot по видам ирисов

names(iris)
colors.iris=c(rep('darkorange2', 50), # заготовим вектор с цветами
         rep('darkorchid3', 50), # функция rep создает вектор с повторяющимися значениями
         rep('chartreuse4', 50)) # сначала указывается значение, затем число его повторов

par(mfrow=c(1,2))
plot(iris$Sepal.Length, iris$Sepal.Width, pch=16, col=colors.iris, cex=1.5,
     main='Sepal')
legend('topleft', legend=c('setosa', 'versicolor', 'virginica'), # добавим легенду 
       col=c('darkorange2', 'darkorchid3', 'chartreuse4'), pch=16, cex=1.2)
# topleft - положение легенды на графике, можно указать координаты цифрами
# legend - названия элементов легенды
plot(iris$Petal.Length, iris$Petal.Width, pch=16, col=colors.iris, cex=1.5,
     main='Petal')
legend('bottomright', legend=c('setosa', 'versicolor', 'virginica'), 
       col=c('darkorange2', 'darkorchid3', 'chartreuse4'), pch=16, cex=1.2)