getwd() # узнать рабочую директорию (и при необходимости изменить!)

trees=read.csv('trees.csv')
trees

names(trees)
head(trees)

# Частота - сколько раз встретилось в выборке наблюдение
# Генеаральная совокупность
# Выборка

# Качественные перменные

trees.count=table(trees$species) # посчитать частоты качественной перменной 
trees.count
barplot(trees.count) # столбиковая диаграмма для визуализации частот качественной переменной

colors=c('dodgerblue4', 'gold2', 'gray', 'darksalmon', 'firebrick3', 'black')
# названия цветов http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf

barplot(trees.count, 
        las=1,
        ylab='Число деревьев', xlab='Деревья',
        col=colors)
box()

# Количественные переменные

# меры центральной тенденции
mean(trees$DBH) # среднее значение диаметра
quantile(trees$DBH) # квантили (медиана - 50% квантиль)
median(trees$DBH) # функция для расчета медианы

getmode <- function(v) { # функция для расчета моды, написанная пользователем
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
getmode(trees$DBH)



# меры разброса
min(trees$DBH) # минимальное значение диаметра
max(trees$DBH) # максимальное значение диаметра
max(trees$DBH)-min(trees$DBH) # разброс

?var

var(trees$DBH) # дисперсия (средний квадрат отклонений от среднего)
var(trees$heigth) # дисперсия, по-английски variance https://en.wikipedia.org/wiki/Variance

# Гистограмма

hist(trees$DBH) # построить гистрограмму распределения диаметров

shapiro.test(trees$DBH) # критерий Шапиро-Уилка для оценки нормальности распределения. H0 - ?
qqnorm(trees$DBH) # график нормальных квантилей. Если распределение нормальное,
# точки должны быть расположены в диагональную линию.
# Этот график сравнивает наши данные с теоретическими квантилями, которые были бы,
# если бы наше распределение было нормальным
qqline(trees$DBH) # добавить линию для удобства интерпретации



# как выглядят данные с нормальным распределением?
ex.data=rnorm(4999) # сделать выборку с данными, распределенными нормально
hist(ex.data)
shapiro.test(ex.data)
qqnorm(ex.data)
qqline(ex.data)


#вернемся к нашей гистограмме распределения диаметров
hist(trees$DBH, breaks=c(0,10,20,30,40,50,60)) # изменим размеры классовых интервалов


hist(trees$DBH, breaks=c(0,10,20,30,40,50,60),
     xlab='?', ylab='?',
     main='Диаметры стволов',
     las=1)

# добавим на гистограмму среднее и медиану
hist(trees$DBH, breaks=c(0,10,20,30,40,50,60),
     xlab='?', ylab='?',
     main='Диаметры стволов',
     las=1)
box() # добавим рамочку
abline(v=mean(trees$DBH), col='red', lwd=3, lty=2) # добавим линию со средним
abline(v=quantile(trees$DBH)[3], col='blue', lwd=3, lty=2) # добавим линию с медианой
abline(v=max(table(trees$DBH)), col='forestgreen', lwd=3, lty=2)

# посмотрим на распределение высот
hist(trees$heigth)

getmode(trees$heigth)

table(trees$heigth)
sort(table(trees$heigth), decreasing = TRUE)

max(trees$heigth)-min(trees$heigth)


hist(trees$heigth, breaks=14,
     xlab='?', ylab='?',
     main='Высоты деревьев')
box()
abline(v=mean(trees$heigth), col='red', lwd=3, lty=2) # добавим линию со средним
abline(v=median(trees$heigth), col='blue', lwd=3, lty=2) # добавим линию с медианой
abline(v=7.6, col='forestgreen', lwd=3, lty=2)
abline(v=25.4, col='forestgreen', lwd=3, lty=2)


#### Связана ли высота с диаметром?
plot(x=trees$DBH, y=trees$heigth,
     xlab='Диаметр ствола, см', ylab='Высота деревьев, м',
     pch=16, col='deepskyblue3', cex=1.2, las=1)

cor(trees$DBH, trees$heigth) # посчитаем коэффициент линейной корреляции
# между высотой и диаметром


#
##
### Сделаем несколько графиков на одном рисунке и сохраним их в файл
tiff(width = 3000, height = 1000, res=300, filename = 'figure1.tif') # записать картинку в файл tif
# width and height - шириина и высота изображения в пикселях
# res - разрешение
# filename - название файла
# готовый файл ищите в рабочей директории
par(mfrow=c(1,3))
#график 1 Гистограмма распределения диаметров
hist(trees$DBH, breaks=c(0,10,20,30,40,50,60),
     xlab='Диаметр ствола, см', ylab='Число деревьев',
     main='Диаметры стволов',
     las=1)
box()
abline(v=mean(trees$DBH), col='red', lwd=3, lty=2)
abline(v=quantile(trees$DBH)[3], col='blue', lwd=3, lty=2)
abline(v=max(table(trees$DBH)), col='forestgreen', lwd=3, lty=2)
# график 2 Гистрограмма распределения высот
hist(trees$heigth, breaks=14,
     xlab='Высота, м', ylab='Число деревьев',
     main='Высоты деревьев', las=1)
box()
abline(v=mean(trees$heigth), col='red', lwd=3, lty=2) # добавим линию со средним
abline(v=median(trees$heigth), col='blue', lwd=3, lty=2) # добавим линию с медианой
abline(v=7.6, col='forestgreen', lwd=3, lty=2)
abline(v=25.4, col='forestgreen', lwd=3, lty=2)
# График 3 Точечный
plot(x=trees$DBH, y=trees$heigth,
     xlab='Диаметр ствола, см', ylab='Высота деревьев, м',
     pch=16, col='deepskyblue3', cex=1.2, las=1,
     main='Взаимосвязь высоты и диаметра')
dev.off() # конец записи картинки


## Есть ли различия в высотах и диаметрах между разными видами деревьев

boxplot(trees$DBH~trees$species) # боксплот или ящик с усами
boxplot(trees$DBH~trees$species, range=0) # усы будут показывать минимум и максимум


trees.sel=trees[trees$species==c('spruce','linden'), ] # выбрать данные только для липы и ели
dim(trees)
dim(trees.sel)


boxplot(trees.sel$DBH~trees.sel$species, range=0) # боксплот с диаметрами липы и ели

colors=c('goldenrod2', 'tomato') # заготовим ветор с цветами
meanDBH=c(mean(trees.sel[trees.sel$species=='linden', 3]), # средний диаметр липы
          mean(trees.sel[trees.sel$species=='spruce', 3])) # средний диаметр ели

boxplot(trees.sel$DBH~trees.sel$species, range=0, 
        col=colors, medcol=colors, # раскрасим медиану в цвет боксплота, чтобы она не была видна
        main='Диаметры стволов')
points(x=c(1,2), y=meanDBH, pch=16, cex=1.5) #добавим на боксплоты точки со средними

t.test(trees.sel$DBH~trees.sel$species) # посчитаем критерий Стъюдента и проверим
# есть ли статистически значимые различия в диаметрах стволов


#### высоты
meanDBH=c(mean(trees.sel[trees.sel$species=='linden', 4]), 
          mean(trees.sel[trees.sel$species=='spruce', 4]))

boxplot(trees.sel$heigth~trees.sel$species, range=0, 
        col=colors, medcol=colors,
        main='Высота деревьев')
points(x=c(1,2), y=meanDBH, pch=16, cex=1.5)

t.test(trees.sel$heigth~trees.sel$species)


###сделаем оба боксплота на одной картинке и запишем в файд figure2
tiff(width = 1400, height = 3000, res=300, filename = 'figure2.tif')
par(mfrow=c(2,1))
boxplot(trees.sel$DBH~trees.sel$species, range=0, 
        col=colors, medcol=colors,
        main='Диаметры стволов')
points(x=c(1,2), y=meanDBH, pch=16, cex=1.5)
boxplot(trees.sel$heigth~trees.sel$species, range=0, 
        col=colors, medcol=colors,
        main='Высоты деревьев')
points(x=c(1,2), y=meanDBH, pch=16, cex=1.5)
dev.off()
