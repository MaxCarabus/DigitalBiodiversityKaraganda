setwd('/home/carabus/bdi/Karaganda/modelling')

library(raster)

# границы Казахстана
KZbounds = shapefile('../sources/countries/KZ_boundaries/gadm41_KAZ_0.shp')
plot(KZbounds)
res = 'wc2.1_2.5m/'
prdir = paste0('../../predictors/Worldclim/',res)
layers = list.files(path = prdir, full.names = T)
lcount = length(layers)

# earthenv
prdir = '../../predictors/EarthEnv/'
layers = list.files(path = prdir, full.names = T)
lcount = length(layers)


for (i in c(1:lcount)) {  
  file = layers[i]
  layer = raster(file)
  tempc = crop(layer,KZbounds)
  tempm = mask(tempc, KZbounds)
  file = basename(file)
  # if (i < 10) file = paste0('wc_bio0',i)
  # if (i > 9) file = paste0('wc_bio',i)
  writeRaster(tempm, filename = paste0('predictors/EarthEnv/',file,'_KZ.tif'))
}

env05shrub = raster('predictors/EarthEnv/env_05_shrubs.tif_KZ.tif')
plot(env05shrub)

env06herb = raster('predictors/EarthEnv/env_06_herb.tif_KZ.tif')
plot(env06herb)

env11barren = raster('predictors/EarthEnv/evn_11_barren.tif_KZ.tif')
plot(env11barren)

env07cultivated = raster('predictors/EarthEnv/env_07_cultivated.tif_KZ.tif')
plot(env07cultivated)

env04mixedtrees = raster('predictors/EarthEnv/env_04_mixed_trees.tif_KZ.tif')
plot(env04mixedtrees)

env01neeldle = raster('predictors/EarthEnv/env_01_needleleaf.tif_KZ.tif')
plot(env01neeldle)
