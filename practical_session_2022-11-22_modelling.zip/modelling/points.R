setwd('/home/carabus/bdi/Karaganda/modelling')
library(rgbif)

# Полевая мышь
sp = 'Apodemus agrarius'

# краснощекий суслик
# sp = 'Spermophilus erythrogenys'

spID = name_backbone(sp)
spID$usageKey
spID$scientificName
occ_count(taxonKey = spID$usageKey)

terms = c('key','scientificName','decimalLatitude','decimalLongitude','country','countryCode')
occurs = occ_search(taxonKey = spID$usageKey, country = 'KZ', fields = terms)$data
occurs = occ_search(taxonKey = spID$usageKey, fields = terms)$data

nrow(occurs)
head(occurs)
colnames(occurs)

occurs$decimalLongitude
occurs = occurs[!is.na(occurs$decimalLongitude),]
occurs$decimalLatitude
nrow(occurs)


# удаляем дубликаты
colnames(occurs)
occurs[,3:4]
dups = duplicated(occurs[,3:4])
occurs = occurs[!dups,]
nrow(occurs)

KZbounds = shapefile('gadm41_KAZ_0.shp')

plot(KZbounds)
points(occurs$decimalLongitude,occurs$decimalLatitude, pch = 16, col = 'blue', cex = 0.5)

coordinates(occurs) = ~ decimalLongitude + decimalLatitude
plot(occurs)
occursKZ = intersect(occurs, KZbounds)

title = paste0('находки ',sp,' в Казахстане')

plot(occursKZ, pch = 16, col = 'blue', cex = .8, main = title)
plot(KZbounds, add = T)

plot(KZbounds, border = 'orange', lwd = 1.5, main = title)
plot(occursKZ, pch = 16, col = 'blue', cex = .8, add = T)
length(occursKZ$key)

occursKZ$countryCode

write.csv(occursKZ,'temp1.csv')
write.csv(occurs,'Apodemus.csv')
