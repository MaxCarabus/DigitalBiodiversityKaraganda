setwd('/home/carabus/bdi/Karaganda/modelling')

library(dismo)
library(PerformanceAnalytics)


points = read.csv('Apodemus.csv')

layers = list.files(path = 'predictors/WorldClim', full.names = T)

wcStack = stack(layers)
names = c('BIO01','BIO02','BIO03','BIO04','BIO05','BIO06','BIO07','BIO08','BIO09',
          'BIO10','BIO11','BIO12','BIO13','BIO14','BIO15','BIO16','BIO17',
          'BIO18','BIO19','elevation')
names(wcStack) = names
plot(wcStack)

colnames(points)
class(points)
coordinates(points) = ~ decimalLongitude + decimalLatitude
class(points)

bgpoints = randomPoints(wcStack$BIO1, 500)
class(bgpoints)
bgpoints = as.data.frame(bgpoints)
class(bgpoints)
coordinates(bgpoints) = ~ x + y

plot(wcStack$BIO1)
points(bgpoints$x,  bgpoints$y, add = T, col = 'blue')
points(points, pch = 16, col = 'red', cex = 0.8)


precenseValues = extract(wcStack,points)
absenceValues  = extract(wcStack,bgpoints)
presence = c(rep(1,nrow(precenseValues)), rep(0,nrow(absenceValues)))

sdmdata = data.frame(presence, rbind(precenseValues,absenceValues))
write.csv(sdmdata, 'sdmdata.csv')

# Регрессионная модель
colnames(sdmdata)

predictors = sdmdata[,2:21]

chart.Correlation(precenseValues[,1:20])

chart.Correlation(predictors)
colnames(predictors)
predictors$BIO05 = NULL
predictors$BIO06 = NULL
predictors$BIO09 = NULL
predictors$BIO10 = NULL
predictors$BIO11 = NULL
predictors$BIO18 = NULL

chart.Correlation(predictors)

predictors$BIO13 = NULL
predictors$BIO16 = NULL
predictors$BIO03 = NULL
predictors$BIO07 = NULL

chart.Correlation(predictors)

predictors$BIO17 = NULL

colnames(predictors)

head(sdmdata)

model1 = glm(presence ~ BIO01 + BIO02 + BIO04 + BIO08 + BIO12 + BIO14 + BIO15 +
               BIO19 + elevation, data = sdmdata, family = 'binomial')
summary(model1)             

model2 = glm(presence ~ BIO01 + BIO02 +BIO12 + BIO19 + elevation, data = sdmdata, family = 'binomial')
summary(model2)             

model2_p = predict(wcStack, model2, type = 'response')
plot(model2_p)
plot(points,add=T)

model2_ev = evaluate(sdmdata[sdmdata$presence == 1,], sdmdata[sdmdata$presence == 0,], model2)
plot(model2_ev, 'ROC')

pointsApodemus = read.csv('Apodemus.csv')
colnames(pointsApodemus)
inputData = pointsApodemus[,4:5]
inputData$type = sample(1:5, nrow(inputData), replace = T)
trainData = inputData[inputData$type != 5,]
testData = inputData[inputData$type == 5,]
nrow(trainData)
nrow(testData)
class(trainData)

meStack = wcStack[[c(1,2,4,8,12,14,15,19,20)]]

maxModel1 = maxent(meStack, trainData[,1:2])
plot(maxModel1)
response(maxModel1)

bg = randomPoints(meStack, 1000)
colnames(bg) = c('decimalLongitude','decimalLatitude')
bg = as.data.frame(bg)
plot(bg$decimalLongitude, bg$decimalLatitude)

plot(maxModel1)

evalt = evaluate(trainData[,1:2], bg, maxModel1, meStack)
evalt

map = predict(meStack,maxModel1)
plot(map)
plot(points,add = T)

plot(evalt, 'ROC')